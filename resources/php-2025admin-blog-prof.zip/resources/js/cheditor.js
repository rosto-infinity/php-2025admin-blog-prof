/*
 * Cheditor minimal loader (version simplifiée)
 * Pour la version complète, voir https://github.com/cheditor/cheditor
 */
class cheditor {
    constructor(options) {
        this.element = options.element;
        this.height = options.height || 300;
        this.init();
    }
    init() {
        // Crée un iframe pour l'éditeur
        const iframe = document.createElement('iframe');
        iframe.style.width = '100%';
        iframe.style.height = this.height + 'px';
        iframe.style.border = '1px solid #ccc';
        this.element.parentNode.insertBefore(iframe, this.element);
        try {
            this.element.style.display = 'none';
            // Charge le contenu initial
            iframe.contentDocument.body.innerHTML = this.element.value;
            // Synchronise le contenu à la soumission
            if (this.element.form) {
                this.element.form.addEventListener('submit', () => {
                    this.element.value = iframe.contentDocument.body.innerHTML;
                });
            }
        } catch (e) {
            // En cas d'erreur, on affiche le textarea
            this.element.style.display = '';
            console.error('Erreur Cheditor :', e);
        }
        // Ajoute une barre d'outils minimale
        const toolbar = document.createElement('div');
        toolbar.innerHTML = `
            <button type="button" onclick="document.querySelector('iframe').contentDocument.execCommand('bold', false, null)"><b>B</b></button>
            <button type="button" onclick="document.querySelector('iframe').contentDocument.execCommand('italic', false, null)"><i>I</i></button>
            <button type="button" onclick="document.querySelector('iframe').contentDocument.execCommand('underline', false, null)"><u>U</u></button>
        `;
        this.element.parentNode.insertBefore(toolbar, iframe);
    }
}
