 <footer>
        <div class="footer-content">
            <h3>Web stage php</h3> <br>
            <div class="footer-links">
                <a href="#" class="footer-link">
                    <i class='bx bxl-twitter'></i>Twitter
                </a>
                <span class="footer-divider">•</span>
                <a href="#" class="footer-link">
                    <i class='bx bxl-discord-alt'></i>Discord
                </a>
                <span class="footer-divider">•</span>
                <a href="#" class="footer-link">
                    <i class='bx bx-rss'></i>RSS
                </a>
                <span class="footer-divider">•</span>
                <a href="#" class="footer-link">
                    <i class='bx bxl-github'></i>GitHub
                </a>
                <span class="footer-divider">•</span>
                <a href="#" class="footer-link">
                    <i class='bx bx-notepad'></i>Mentions légales
                </a>
                <span class="footer-divider">•</span>
                <a href="#" class="footer-link">
                    <i class='bx bx-info-circle'></i>A propos
                </a>
                <a href="admin-dashboard.php" class="footer-link">
                    <i class='bx bx-user-check'></i>Admin
                </a>
            </div>
            <div class="copyright">
                © 2025 Blog PHP, tous droits réservés
            </div>
        </div>
    </footer>
  
  
  <script src="/resources/js/blog.js"></script>
  <script src="/resources/js/apexcharts.js"></script>