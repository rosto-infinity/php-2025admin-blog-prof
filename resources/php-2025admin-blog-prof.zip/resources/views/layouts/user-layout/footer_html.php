
	<script src="/resources/js/apexcharts.js"></script>
	<script src="/resources/js/script.js"></script>
