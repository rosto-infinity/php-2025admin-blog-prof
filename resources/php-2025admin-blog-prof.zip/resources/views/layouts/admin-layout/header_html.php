	<!-- NAVBAR -->
		<nav>
			<i class='bx bx-menu toggle-sidebar' ></i>
			<form action="#">
				<div class="form-group">
					<input type="text" placeholder="Search...">
					<i class='bx bx-search icon' ></i>
				</div>
			</form>



			<a href="#" class="nav-link">
				<i class='bx bxs-bell icon' ></i>
				<span class="badge">5</span>
			</a>
			<a href="#" class="nav-link">
				<i class='bx bxs-message-square-dots icon' ></i>
				<span class="badge">8</span>
			</a>
			<span class="divider"></span>
			
			 <div class="profile">
        <img src="/publicAll/images/profil.png" alt="waffolele">
        <ul class="profile-link">
            <li>
                <a href="#">
                    <i class='bx bxs-cog'></i> Paramètres
                </a>
            </li>
            <li>
                <a href="/logout.php">
                    <i class='bx bxs-log-out-circle'></i> Déconnexion
                </a>
            </li>
        </ul>
       </div>
		</nav>
		<!-- End - NAVBAR -->
