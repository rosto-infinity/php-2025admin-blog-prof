	<!-- SIDEBAR -->
	<section id="sidebar">
		<a href="/admin-dashboard.php" class="brand"><i class='bx bxs-smile icon'></i> AdminSite</a>
		<ul class="side-menu">
			<li><a href="/admin-dashboard.php" class="active"><i class='bx bxs-dashboard icon' ></i> Dashboard</a></li>
			<li><a href="index.php"><i class='bx bxs-home icon'></i> Blog welcome</a></li>
			<li style="color:gray" >Blog</li>
			<li>

				<a href="#"><i class='bx bxs-inbox icon' ></i> Articles <i class='bx bx-chevron-right icon-right' ></i></a>
				<ul class="side-dropdown">
					<li><a href="/list-article.php">Tous les articles</a></li>
					<li><a href="/admin.php">Ajouter</a></li>
				</ul>
			</li>
			<li><a href="#"><i class='bx bxs-chart icon' ></i> Categories</a></li>
			<li><a href="/list-comment.php"><i class='bx bxs-widget icon' ></i> Commentaires</a></li>
			<li style="color:gray">Stagères</li>
			<li>
				<a href="/list-users.php"><i class='bx bxs-notepad icon' ></i> Users 
			</li>
				

		</ul>
		<!-- <div class="ads">
			<div class="wrapper">
				<a href="#" class="btn-upgrade">Upgrade</a>
				<p>Become a <span>PRO</span> member and enjoy <span>All Features</span></p>
			</div>
		</div> -->
	</section>
	<!-- End - SIDEBAR -->